﻿namespace $safeprojectname$.ViewModels
{
    public class WelcomeViewModel : BasePageViewModel
    {
    }
}
