﻿namespace $safeprojectname$.Views.Pages
{
    public partial class WelcomePage
    {
        public WelcomePage() =>
            InitializeComponent();
    }
}