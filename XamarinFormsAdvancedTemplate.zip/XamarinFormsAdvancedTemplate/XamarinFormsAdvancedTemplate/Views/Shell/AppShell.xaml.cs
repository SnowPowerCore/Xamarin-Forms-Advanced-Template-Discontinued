﻿namespace $safeprojectname$.Views.Shell
{
    public partial class AppShell
    {
        public AppShell() =>
            InitializeComponent();
    }
}