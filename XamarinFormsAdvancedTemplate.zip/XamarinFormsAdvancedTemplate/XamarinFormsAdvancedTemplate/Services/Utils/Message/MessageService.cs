﻿using System.Threading.Tasks;
using Xamarin.Forms;
using $safeprojectname$.Resources;
using $safeprojectname$.Services.Interfaces;
using $safeprojectname$.Services.Utils.Settings;
using XF.Material.Forms.UI.Dialogs;

namespace $safeprojectname$.Services.Utils.Message
{
    public class MessageService : IMessageService
    {
        #region Fields
        private readonly IToast _toast;
        private readonly ISettingsService _settings;
        #endregion

        #region Constructor
        public MessageService(IToast toast,
                              ISettingsService settings)
        {
            _toast = toast;
            _settings = settings;
        }
        #endregion

        #region Methods
        public Task<bool> DisplayConfirmationAsync(string dialogName, string dialogDesc, string confirmLabel, string denyLabel)
        {
            var tcs = new TaskCompletionSource<bool>();
            Device.InvokeOnMainThreadAsync(async () =>
            {
                var result = await MaterialDialog.Instance.ConfirmAsync(
                    dialogDesc,
                    dialogName,
                    "OK",
                    AppResources.cancel);
                tcs.SetResult(result.GetValueOrDefault());
            });
            return tcs.Task;
        }

        public Task<string> DisplayInputAsync(string title = "", string message = "", string inputText = null, string inputPlaceholder = "") =>
            MaterialDialog.Instance.InputAsync(
                title,
                message,
                inputText,
                inputPlaceholder,
                "OK",
                AppResources.cancel);

        public Task DisplayErrorDescOnlyAsync(string errorDesc) =>
            MaterialDialog.Instance.AlertAsync(errorDesc);

        public Task DisplayInfoAsync(string message) =>
            MaterialDialog.Instance.AlertAsync(message);

        public Task DisplaySnackbarAsync(string info, int duration = 1500) =>
            MaterialDialog.Instance.SnackbarAsync(info, duration);

        public void DisplayToast(string info) =>
            _toast.ShowToast(info);

        public Task<IMaterialModalPage> DisplayLoadingAsync(string message) =>
            MaterialDialog.Instance.LoadingDialogAsync(message);
        #endregion
    }
}