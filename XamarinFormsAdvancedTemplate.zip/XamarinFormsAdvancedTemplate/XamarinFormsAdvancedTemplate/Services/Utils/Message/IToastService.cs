﻿namespace $safeprojectname$.Services.Utils.Message
{
    public interface IToastService
    {
        void DisplayToast(string info);
    }
}