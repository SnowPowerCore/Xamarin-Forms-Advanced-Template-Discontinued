﻿namespace $safeprojectname$.Services.Interfaces
{
    public interface IKeyboard
    {
        void HideKeyboard();
    }
}