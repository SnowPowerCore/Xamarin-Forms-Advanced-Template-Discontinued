﻿namespace $safeprojectname$.Services.Interfaces
{
    public interface IAppQuit
    {
        void Quit();
    }
}