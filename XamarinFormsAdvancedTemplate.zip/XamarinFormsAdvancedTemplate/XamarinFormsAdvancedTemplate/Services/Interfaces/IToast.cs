﻿namespace $safeprojectname$.Services.Interfaces
{
    public interface IToast
    {
        void ShowToast(string message);
    }
}