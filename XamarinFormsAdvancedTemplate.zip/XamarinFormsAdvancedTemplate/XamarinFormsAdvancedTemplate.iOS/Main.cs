﻿using UIKit;

namespace $safeprojectname$
{
    public class Application
    {
        static void Main(string[] args) =>
            UIApplication.Main(args, null, "AppDelegate");
    }
}
