﻿using UIKit;
using $ext_safeprojectname$.Services.Interfaces;

namespace $safeprojectname$.Implementations
{
    public class Keyboard : IKeyboard
    {
        public void HideKeyboard() =>
            UIApplication.SharedApplication.KeyWindow.EndEditing(true);
    }
}