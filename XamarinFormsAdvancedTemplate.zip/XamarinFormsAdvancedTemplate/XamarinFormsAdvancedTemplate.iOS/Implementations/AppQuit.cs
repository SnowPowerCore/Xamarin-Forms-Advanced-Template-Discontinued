﻿using $ext_safeprojectname$.Services.Interfaces;

namespace $safeprojectname$.Implementations
{
    public class AppQuit : IAppQuit
    {
        public void Quit() { }
    }
}