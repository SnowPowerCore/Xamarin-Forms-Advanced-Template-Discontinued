﻿using Xamarin.Forms;
using $ext_safeprojectname$.Services.Interfaces;

namespace $safeprojectname$.Implementations
{
    public class Toast : IToast
    {
        public void ShowToast(string message) =>
            Device.InvokeOnMainThreadAsync(() =>
            {
            });
    }
}